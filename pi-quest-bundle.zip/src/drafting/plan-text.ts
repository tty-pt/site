// HIGH_LEVEL: #drafting — the quest document is plain markdown sections.
// Pure plan-text operations over the draft file: hashing, section splicing,
// parsing, maturity thresholds, and the review-count marker that forces a
// re-review by slightly altering the plan.
import { isHeading, sectionKeyOf, type SectionKey } from "../domain/sections";
import { createHash } from "node:crypto";
import { DEFAULT_CONFIG, type DraftThresholds } from "../config";
import type { QuestDifficulty, QuestKind, QuestState } from "../domain/quest";
import type { ReviewMaterial } from "../review/prompts";
import { checkRtmCoverage, type RtmItem } from "../domain/contract";
import { diffPlans } from "./plan-diff";

export interface DraftSections {
  requirements: string[];
  evidence: string[];
  plan: string;
  // Analysis quests deliver the quest doc's ## Analysis body here (D1).
  analysis: string;
  subquests?: string;
  amendments?: string[];
}

export function hashContent(content: string): string {
  return createHash("sha256").update(content, "utf8").digest("hex");
}

// Generic ##-section splices: replace the named section's body, or append a
// fresh section when absent. Both the plan and the analysis deliverable reuse
// it so their splice semantics stay byte-identical.
function spliceSection(text: string, key: SectionKey, label: string, body: string): string {
  const lines = text.split("\n");
  const start = lines.findIndex((line) => isHeading(line, key));
  if (start === -1) {
    const base = text.endsWith("\n") ? text : `${text}\n`;
    return `${base}\n## ${label}\n\n${body.trim()}\n`;
  }
  let end = lines.length;
  for (let i = start + 1; i < lines.length; i += 1) {
    if (/^##\s+.+?\s*$/.test(lines[i])) {
      end = i;
      break;
    }
  }
  return [...lines.slice(0, start + 1), "", body.trim(), "", ...lines.slice(end)].join("\n");
}

export function splicePlanSection(text: string, plan: string): string {
  return spliceSection(text, "plan", "Implementation Plan", plan);
}

export function spliceAnalysisSection(text: string, analysis: string): string {
  return spliceSection(text, "analysis", "Analysis", analysis);
}

export function spliceSubquestsSection(text: string, subquests: string): string {
  return spliceSection(text, "subquests", "Sub-Quests", subquests);
}

export function spliceAmendmentsSection(text: string, amendments: string[]): string {
  const body = amendments.length > 0
    ? amendments.map((a) => `- ${a}`).join("\n")
    : "<!-- No amendments recorded -->";
  return spliceSection(text, "amendments", "Amendments", body);
}

export function parseDraftSections(text: string): DraftSections {
  const requirements: string[] = [];
  const evidence: string[] = [];
  const planLines: string[] = [];
  const analysisLines: string[] = [];
  const subquestLines: string[] = [];
  const amendments: string[] = [];
  let section: "requirements" | "evidence" | "plan" | "analysis" | "subquests" | "amendments" | null = null;
  let inComment = false;
  for (const line of text.split(/\r?\n/)) {
    const header = line.match(/^##\s+(.+?)\s*$/);
    if (header) {
      const key = sectionKeyOf(header[1]);
      // Pre-draft investigation recorded via recordRefinement is research:
      // its bullets fold into the evidence list so it counts toward the bar.
      if (key === "requirements" || key === "evidence" || key === "analysis" || key === "plan" || key === "amendments") section = key;
      else if (key === "subquests") section = "subquests";
      else if (key === "predraft") section = "evidence";
      else section = null;
      continue;
    }
    if (section === "plan") {
      planLines.push(line);
      continue;
    }
    if (section === "analysis") {
      analysisLines.push(line);
      continue;
    }
    if (section === "subquests") {
      subquestLines.push(line);
      continue;
    }
    const trimmed = line.trim();
    if (inComment) {
      if (trimmed.includes("-->")) inComment = false;
      continue;
    }
    if (trimmed.startsWith("<!--")) {
      if (!trimmed.includes("-->")) inComment = true;
      continue;
    }
    const bullet = line.match(/^\s*(?:[-*+]|\d+[.)])\s+(.+?)\s*$/);
    if (bullet && (section === "requirements" || section === "evidence" || section === "amendments")) {
      if (section === "requirements") requirements.push(bullet[1]);
      else if (section === "evidence") evidence.push(bullet[1]);
      else if (section === "amendments") amendments.push(bullet[1]);
    }
  }
  return {
    requirements,
    evidence,
    plan: planLines.join("\n").trim(),
    analysis: analysisLines.join("\n").trim(),
    subquests: subquestLines.join("\n").trim(),
    amendments,
  };
}

export function extractRtmFromRequirements(requirements: string[]): RtmItem[] {
  const rtm: RtmItem[] = [];
  for (let i = 0; i < requirements.length; i++) {
    const req = requirements[i];
    const clean = req.replace(/^\*+|\*+$/g, "").trim();
    if (!clean) continue;
    const m = clean.match(/^\[?([A-Za-z0-9_-]+)\]?[:\-]\s*(.*)$/);
    if (m && /^R\d+/i.test(m[1])) {
      rtm.push({
        id: m[1].toUpperCase(),
        description: m[2].trim() || m[1].toUpperCase(),
        status: "pending",
        explicit: true,
      });
    } else {
      rtm.push({
        id: `R${i + 1}`,
        description: clean,
        status: "pending",
        explicit: false,
      });
    }
  }
  return rtm;
}

// A deliverable is authored only when something other than HTML comments (the
// review-count marker, template placeholders) is in it.
export function hasAuthoredText(text: string): boolean {
  return text.replace(/<!--[\s\S]*?-->/g, "").trim().length > 0;
}

const RESERVED_SECTIONS = new Set([
  "requirements",
  "evidence",
  "sub-quests",
  "subquests",
  "amendments",
  "analysis",
  "implementation plan",
  "plan",
  "context / background discussion",
  "context",
  "original request",
]);

// The doc is ##-sectioned: reserved top-level sections (## Requirements, ## Evidence)
// cannot be inside a deliverable. Non-reserved ## sub-headings (e.g. ## Phase 1)
// are automatically normalized to ### sub-headings to preserve valid markdown.
export function normalizeDeliverableHeadings(body: string, noun: "plan" | "analysis"): string {
  const lines = body.split(/\r?\n/);
  const normalized: string[] = [];

  for (const line of lines) {
    const match = line.match(/^##\s+(.+)$/);
    if (match) {
      const headingText = match[1].trim().toLowerCase();
      if (RESERVED_SECTIONS.has(headingText)) {
        throw new Error(
          `the ${noun} text contains a reserved section heading (${JSON.stringify(line.trim())}): "## " lines end the ${noun} section in the quest doc. Use "###" for sub-headings inside the ${noun}; requirements and evidence belong in the doc's own ## Requirements and ## Evidence sections (edit the draft file directly).`,
        );
      }
      // Auto-demote non-reserved ## sub-heading to ###
      normalized.push(`### ${match[1].trim()}`);
    } else {
      normalized.push(line);
    }
  }

  const result = normalized.join("\n");
  if (!hasAuthoredText(result)) throw new Error(`the ${noun} text has no content beyond comments`);
  return result;
}

export function assertNoSectionHeadings(body: string, noun: "plan" | "analysis"): string {
  return normalizeDeliverableHeadings(body, noun);
}

export function meetsReviewThresholds(
  sections: DraftSections,
  thresholds = DEFAULT_CONFIG.draftThresholds,
  kind: QuestKind = "standard",
): boolean {
  const req = sections.requirements.length;
  const ev = sections.evidence.length;
  const counts = req >= thresholds.requirements || (req >= 1 && ev >= thresholds.evidence);
  const authored = hasAuthoredText(kind === "analysis" ? sections.analysis : sections.plan);
  if (!counts || !authored) return false;
  if (kind === "standard") {
    const rtm = extractRtmFromRequirements(sections.requirements);
    if (rtm.some((r) => r.explicit)) {
      const coverage = checkRtmCoverage(rtm, sections.plan, sections.requirements.length);
      if (!coverage.covered) return false;
    }
  }
  return true;
}

// The deterministic draft profile the agent sees before and at every save:
// counts, the maturity-bar verdict, and what is missing to clear it. It is the
// agent's free look at what the reviewer will check, without a review boot.
export function draftProfileText(
  sections: DraftSections,
  thresholds: DraftThresholds,
  citationSummary = "",
  kind: QuestKind = "standard",
  difficulty?: QuestDifficulty,
): string {
  const analysis = kind === "analysis";
  const req = sections.requirements.length;
  const ev = sections.evidence.length;
  const noun = analysis ? "analysis" : "plan";
  const deliverable = analysis ? sections.analysis : sections.plan;
  const planPresent = hasAuthoredText(deliverable);
  const counts = req >= thresholds.requirements || (req >= 1 && ev >= thresholds.evidence);
  const rtm = extractRtmFromRequirements(sections.requirements);
  const hasExplicitRtm = rtm.some((r) => r.explicit);
  const rtmCoverage = kind === "standard" && hasExplicitRtm
    ? checkRtmCoverage(rtm, sections.plan, sections.requirements.length)
    : { covered: true, missing: [], total: rtm.length, coveredCount: rtm.length };
  const meets = counts && planPresent && rtmCoverage.covered;
  const gapLeg = ` (needs ${thresholds.requirements} requirements, or 1 requirement + ${thresholds.evidence} evidence, with an ${analysis ? "authored analysis" : "actionable plan"})`;
  const diffTag = difficulty ? ` (difficulty: ${difficulty})` : "";
  const lines = [
    `draft profile${diffTag}: requirements ${req}, evidence ${ev}, ${noun} ${planPresent ? "present" : "missing"}`,
  ];
  if (meets) {
    lines.push(`reviewability: maturity bar: met${gapLeg}`);
  } else {
    const gaps: string[] = [];
    if (!planPresent) gaps.push(`author the ## ${analysis ? "Analysis" : "Implementation Plan"} section`);
    if (req < thresholds.requirements && ev < thresholds.evidence) {
      gaps.push(`add ${thresholds.requirements - req} more requirements, or ${thresholds.evidence - ev} more evidence items with at least 1 requirement`);
    } else if (req < thresholds.requirements) {
      gaps.push(`add ${thresholds.requirements - req} more requirements`);
    } else if (ev < thresholds.evidence) {
      gaps.push(`add ${thresholds.evidence - ev} more evidence items`);
    }
    if (!rtmCoverage.covered) {
      gaps.push(`map requirement(s) ${rtmCoverage.missing.join(", ")} into the plan or sub-quest backlog`);
    }
    lines.push(`reviewability: maturity bar NOT met${gapLeg}; missing: ${gaps.join("; ") || "none"}`);
  }
  if (citationSummary !== "") lines.push(citationSummary);
  return lines.join("\n");
}

// --- Claim citations --------------------------------------------------------
// File:line citations are the plan's verifiable surface. Parsed purely so the
// save path can warn on drift and the review brief can carry a CLAIM MANIFEST.

export interface PlanCitation {
  file: string;
  lineStart: number;
  lineEnd: number | undefined;
}

const CITATION_RE =
  /((?:\.{1,2}\/|\.)?[A-Za-z0-9_][A-Za-z0-9_./-]*\.(?:c|h|ts|md|sh|js|mjs|json|py|mk|yml|yaml|toml|rs|go|css|html|cc|cpp|hpp))[:](\d+)(?:-(\d+))?/g;

// URLs like http://host/y.c:5 look like citations but are not local refs.
export function citeLocations(text: string): PlanCitation[] {
  const out: PlanCitation[] = [];
  const scrubbed = text.replace(/[A-Za-z][A-Za-z0-9+.-]*:\/\/[^\s)]+/g, " ");
  const re = new RegExp(CITATION_RE.source, "g");
  let m: RegExpExecArray | null;
  while ((m = re.exec(scrubbed)) !== null) {
    const lineEnd = m[3] === undefined ? undefined : Number(m[3]);
    out.push({ file: m[1], lineStart: Number(m[2]), lineEnd });
  }
  return out;
}

// The reviewer spot-checks these instead of re-deriving the whole tree. For
// analysis quests, the claim surface is the ## Analysis body, not the plan.
export function buildClaimManifest(sections: DraftSections, kind: QuestKind = "standard"): string {
  const lines: string[] = [];
  for (const item of sections.evidence) {
    lines.push(`- Evidence claim (verify in repo): ${item}`);
  }
  const deliverable = deliverableBody(sections, kind);
  for (const cite of citeLocations(deliverable)) {
    lines.push(`- Cited location: ${cite.file}:${cite.lineStart}${cite.lineEnd !== undefined ? `-${cite.lineEnd}` : ""}`);
  }
  return lines.join("\n");
}

// The review-count marker lives inside the Implementation Plan section: an
// HTML comment, invisible in render, ignorable by the reviewer. Bumping it
// changes the content hash, so a failed review re-boots through the one
// save→boot pipeline and survives a mid-retry restart.
export const REVIEW_COUNT_MARKER = /^<!--\s*pi-quest:\s*review-count\s+(\d+)\s*-->\s*$/i;
export const REVIEW_COUNT_LINE = (count: number): string => `<!-- pi-quest: review-count ${count} -->`;

// Agent plan writes seed the counter at zero; stale agent-carried markers
// never survive.
export function seedReviewCount(plan: string): string {
  const lines = plan.split("\n").filter((line) => !REVIEW_COUNT_MARKER.test(line.trim()));
  return [REVIEW_COUNT_LINE(0), ...lines].join("\n");
}

// Retry bumps rewrite the quest doc with the incremented count. No deliverable
// body means no bootable review: the text is returned untouched. For analysis
// quests the marker lands inside the ## Analysis body (D1).
export function bumpReviewCount(text: string, count: number, kind: QuestKind = "standard"): string {
  const sections = parseDraftSections(text);
  const deliverable = deliverableBody(sections, kind);
  const deliverableLines = deliverable
    .split("\n")
    .filter((line) => line.trim() !== "" && !REVIEW_COUNT_MARKER.test(line.trim()));
  if (deliverableLines.length === 0) return text;
  const bumped = [REVIEW_COUNT_LINE(count), ...deliverableLines].join("\n");
  return kind === "analysis" ? spliceAnalysisSection(text, bumped) : splicePlanSection(text, bumped);
}

// The deliverable a quest commits: standard quests an Implementation Plan,
// analysis quests the Analysis itself (D1). Every section-target site keys on
// this single selector.
export function deliverableBody(sections: DraftSections, kind: QuestKind): string {
  if (kind === "analysis") return sections.analysis;
  if (sections.subquests && sections.subquests.length > 0) {
    return sections.plan
      ? `## Sub-Quests\n${sections.subquests}\n\n${sections.plan}`
      : `## Sub-Quests\n${sections.subquests}`;
  }
  return sections.plan;
}

export function deliverableWord(kind: QuestKind): string {
  return kind === "analysis" ? "Analysis" : "Plan";
}

// The re-review brief must diff against the previously reviewed deliverable,
// never against the one being sent. Analysis quests target the analysis body.
export function reviewMaterial(state: QuestState, sections: DraftSections): ReviewMaterial {
  const analysis = state.kind === "analysis";
  const deliverable = deliverableBody(sections, state.kind);
  const openRebuttal = [...state.reviewDialogue].reverse().find((d) => d.verdictAfter === undefined);
  const stateAmendments = state.amendments.map((a: { change: string; reasons: string }) => `${a.change} (${a.reasons})`);
  const allAmendments = Array.from(new Set([...stateAmendments, ...(sections.amendments ?? [])]));
  const base: ReviewMaterial = {
    objective: state.pendingRootRequest ?? state.objective,
    plan: deliverable,
    kind: state.kind,
    difficulty: state.difficulty,
    requirements: sections.requirements,
    evidence: sections.evidence,
    amendments: allAmendments,
    rebuttal: openRebuttal?.implementerRebuttal,
    claimManifest: buildClaimManifest(sections, state.kind),
  };
  const last = state.lastReview;
  const previous = state.draft?.lastReviewedPlan;
  if (last === null || previous === undefined || previous === null) return base;
  // Prior verdict always travels: an evidence-only revision answers the last
  // findings even when the deliverable itself is unchanged (then diffPlans is null).
  const continued: ReviewMaterial = {
    ...base,
    previousVerdict: last.verdict,
    previousFindings: last.findings,
  };
  const planDiff = diffPlans(previous, deliverable);
  if (planDiff === null) return continued;
  return { ...continued, planDiff };
}
