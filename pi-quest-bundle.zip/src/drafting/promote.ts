// HIGH_LEVEL: #modes — kind-aware draft PASS routing: standard quests promote
// to implementing; analysis quests auto-claim straight to validating (D3),
// falling back to a work phase while sub-quests are still running.
import { emitNow } from "../app/interpreter";
import { getState, replaceState, updateState } from "../app/store";
import type { ApprovedBy } from "../domain/quest";
import { promote, promoteToValidation } from "../domain/transitions";
import { unfinishedChildren } from "../domain/children";
import { nextQid, type Qid } from "../domain/qid";
import { launchValidation } from "../validation/flow";
import type { Pi, PiCtx } from "../hooks/events";
import { ensureChildDraftFile, listKnownQids, draftFilePath } from "../files";
import { advanceForeman } from "../subquests/foreman";
import { cancelReview } from "../review/tracker";
import { readFile } from "node:fs/promises";
import { parseDraftSections, extractRtmFromRequirements } from "./plan-text";
import type { RtmItem } from "../domain/contract";

// Shared by the reviewer-PASS auto-promote path (drafting/reviews.ts) and the
// live-user "go" path. Returns the promotion message to steer/wake — the
// caller's medium differs — or null when the quest is no longer drafting.
export async function promoteAfterPass(
  pi: Pi,
  ctx: PiCtx,
  qid: Qid,
  by: ApprovedBy,
): Promise<string | null> {
  const state = getState();
  if (state.phase !== "drafting" || state.qid !== qid) return null;
  if (state.draft === null || !state.draft.planAuthored) return null;
  cancelReview(qid);
  const stateQid = state.qid;
  const how = by === "user" ? 'user "go"' : "reviewer PASS";

  let rtm: RtmItem[] | undefined;
  try {
    const text = await readFile(draftFilePath(ctx.cwd, stateQid), "utf8");
    const sections = parseDraftSections(text);
    const extracted = extractRtmFromRequirements(sections.requirements);
    if (extracted.length > 0) {
      rtm = extracted;
    }
  } catch {
    // Best-effort extraction
  }

  if (state.kind === "analysis") {
    const unfinished = unfinishedChildren(state);
    if (unfinished.length > 0) {
      updateState((s) => promote(s, by, rtm));
      emitNow(pi);
      return `Quest ${stateQid} promoted to implementing (${how}) — the analysis stays provisional while sub-quests run. Complete and acknowledge each child, then save to re-review; a live user "go" may also override.`;
    }
    updateState((s) => promoteToValidation(s, by, rtm));
    emitNow(pi);
    void launchValidation(pi, ctx, stateQid);
    return `Quest ${stateQid} reached the approved analysis milestone (${how}): on to validation. The doc stays live until the validator concludes.`;
  }
  updateState((s) => promote(s, by, rtm));
  const promoted = getState();
  if (promoted.difficulty === "complex") {
    const knownQids = await listKnownQids(ctx.cwd);
    const nextChildQid = nextQid(Date.now() / 1000, knownQids);
    const advanced = advanceForeman(promoted, nextChildQid);
    if (advanced) {
      await ensureChildDraftFile(ctx.cwd, nextChildQid, stateQid, advanced.contract, advanced.nextItem.goal);
      replaceState(advanced.nextMountedState);
      emitNow(pi);
      return `Quest ${stateQid} promoted to implementing (${how}). Foreman: Automatically mounting ${advanced.nextItem.id}: "${advanced.nextItem.goal}". Allowed paths: ${advanced.nextItem.allowedPaths.join(", ") || "(all)"}. Proceeding with sub-quest implementation.`;
    }
  }
  emitNow(pi);
  return `Quest ${stateQid} promoted to implementing (${how}). Proceed autonomously from the draft plan.`;
}