// HIGH_LEVEL: #sub-quests — contracts, requirement traceability matrix, and handback receipts.
import type { Qid } from "./qid";

export interface RtmItem {
  id: string;
  description: string;
  status: "pending" | "satisfied" | "verified";
  owner?: string;
  explicit?: boolean;
}

export interface SubQuestContract {
  qid: Qid;
  parentQid: Qid;
  title: string;
  assignedRequirements: string[];
  allowedPaths: string[];
  requiredTestCommands: string[];
  acceptanceCriteria: string[];
  maxTurns?: number;
  worktreePath?: string;
  worktreeBranch?: string;
}

export interface HandbackReceipt {
  childQid: Qid;
  status: "COMPLETED" | "FAILED";
  assignedRequirements: string[];
  filesModified: string[];
  diffSummary: string;
  testCommand: string;
  testPassed: boolean;
  findings: string;
}

function matchesPattern(pattern: string, path: string): boolean {
  if (pattern === path) return true;
  // Directory prefix ending with slash: "src/path/" matches "src/path/file.ts"
  if (pattern.endsWith("/")) {
    return path.startsWith(pattern) || path === pattern.slice(0, -1);
  }
  if (pattern.endsWith("/*")) {
    const prefix = pattern.slice(0, -2);
    return path.startsWith(prefix === "" ? "" : `${prefix}/`);
  }
  if (pattern.endsWith("/**")) {
    const prefix = pattern.slice(0, -3);
    return path.startsWith(prefix === "" ? "" : `${prefix}/`);
  }
  // Directory name without trailing slash: "src/path" matches "src/path/file.ts"
  if (path.startsWith(`${pattern}/`)) return true;
  return false;
}

export function isPathAllowedByContract(contract: SubQuestContract, path: string, cwd?: string): boolean {
  if (!contract.allowedPaths || contract.allowedPaths.length === 0) {
    return true;
  }
  let norm = path;
  if (cwd && norm.startsWith(cwd)) {
    norm = norm.slice(cwd.length);
  } else if (norm.startsWith("/") && typeof process !== "undefined" && typeof process.cwd === "function") {
    const pCwd = process.cwd();
    if (norm.startsWith(pCwd)) {
      norm = norm.slice(pCwd.length);
    }
  }
  norm = norm.replace(/^[./]+/, "");
  for (const allowed of contract.allowedPaths) {
    const allowedNorm = allowed.replace(/^[./]+/, "");
    if (matchesPattern(allowedNorm, norm)) return true;
  }
  return false;
}

export function updateRtmFromReceipt(
  rtm: RtmItem[] | undefined,
  receipt: HandbackReceipt,
): RtmItem[] {
  if (!rtm || rtm.length === 0) return [];
  const assigned = new Set(receipt.assignedRequirements);
  return rtm.map((item) => {
    if (assigned.has(item.id)) {
      return {
        ...item,
        status: receipt.status === "COMPLETED" ? ("satisfied" as const) : item.status,
      };
    }
    return item;
  });
}

const STOP_WORDS = new Set([
  "the", "and", "for", "with", "that", "this", "from", "into", "must", "should",
  "have", "been", "will", "when", "what", "where", "which", "then", "them", "they",
  "each", "every", "some", "any", "all", "are", "was", "were", "our", "your",
]);

export interface RtmCoverageResult {
  covered: boolean;
  missing: string[];
  total: number;
  coveredCount: number;
}

export function checkRtmCoverage(
  rtm: RtmItem[] | undefined,
  planText: string,
  requirementsCount?: number,
): RtmCoverageResult {
  if (!rtm || rtm.length === 0) {
    const hasReqs = typeof requirementsCount === "number" && requirementsCount > 0;
    return {
      covered: !hasReqs,
      missing: hasReqs ? ["requirements"] : [],
      total: 0,
      coveredCount: 0,
    };
  }

  if (!planText || planText.trim().length === 0) {
    return {
      covered: false,
      missing: rtm.map((i) => i.id),
      total: rtm.length,
      coveredCount: 0,
    };
  }

  const missing: string[] = [];
  for (const item of rtm) {
    if (item.owner) continue;

    // Check if item id (e.g. "R1" or "[R1]") is referenced in the plan
    const pattern = new RegExp(`\\b${item.id}\\b|\\[${item.id}\\]`, "i");
    if (!pattern.test(planText)) {
      missing.push(item.id);
    }
  }

  const coveredCount = rtm.length - missing.length;
  return {
    covered: missing.length === 0,
    missing,
    total: rtm.length,
    coveredCount,
  };
}
