// HIGH_LEVEL: #review and validation communication.
// HIGH_LEVEL: #review request — brief identifies qid, type, target, plan, evidence, criteria.
// HIGH_LEVEL: #independent review contexts — fresh context per run, no inherited reasoning.
// Pure reviewer launch inputs: a provider-agnostic candidate list plus an
// optional thinking level. This module holds no provider knowledge — the
// parent model passes through verbatim, or is omitted entirely (inherit) so
// the child host and its per-agent overrides govern. Child hosts may
// fabricate a literal `:level` thinking suffix (e.g. `some/model:high`) that
// a registry never registered — the flow therefore also retries the
// suffix-stripped variant instead of failing.
import type { PiCtx } from "../hooks/events";
import { isProviderSideFailure, isRetryableProviderError } from "../utils/provider-error.ts";

// Thinking levels of the delegation contract. Validated here, never chosen:
// absent means inherit.
export const THINKING_LEVELS: ReadonlySet<string> = new Set([
  "off",
  "minimal",
  "low",
  "medium",
  "high",
  "xhigh",
  "max",
]);

function readEnv(name: string): string | undefined {
  try {
    const proc = (globalThis as Record<string, unknown>)["process"] as
      | { env?: Record<string, unknown> }
      | undefined;
    const value = proc?.env?.[name];
    return typeof value === "string" && value.length > 0 ? value : undefined;
  } catch {
    return undefined;
  }
}

// Strips a trailing `:level` thinking suffix from a model id. The id is never
// renamed or remapped — a suffixed id some registries cannot resolve may
// still run as the bare base id.
export function stripThinkingSuffix(model: string): string {
  const trimmed = model.trim();
  const colonIdx = trimmed.lastIndexOf(":");
  if (colonIdx <= 0) return trimmed;
  const suffix = trimmed.substring(colonIdx + 1).toLowerCase();
  return THINKING_LEVELS.has(suffix) ? trimmed.substring(0, colonIdx) : trimmed;
}

// Verbatim passthrough: explicit env first, then the launcher provider/model
// pair, then the live context model. Empty means inherit (the flow then omits
// the `model` field when delegating).
export function resolveDefaultReviewModel(ctx?: PiCtx): string {
  const explicit = readEnv("PI_CRITICAL_REVIEW_MODEL") ?? readEnv("PI_REVIEW_MODEL");
  if (explicit !== undefined) return explicit;
  const provider = readEnv("PI_PROVIDER");
  const model = readEnv("PI_MODEL");
  if (provider !== undefined && model !== undefined) return `${provider}/${model}`;
  if (model !== undefined) return model;
  const ctxModel = (ctx as { model?: unknown } | undefined)?.model;
  if (typeof ctxModel === "string") {
    if (ctxModel.toLowerCase().startsWith("quest/")) return "";
    return ctxModel;
  }
  if (ctxModel !== null && typeof ctxModel === "object") {
    const m = ctxModel as { provider?: unknown; id?: unknown; name?: unknown };
    if (typeof m.provider === "string" && typeof m.id === "string") {
      if (m.provider.toLowerCase() === "quest") return "";
      return `${m.provider}/${m.id}`;
    }
    if (typeof m.id === "string") {
      if (m.id.toLowerCase().startsWith("quest/")) return "";
      return m.id;
    }
    if (typeof m.name === "string") {
      if (m.name.toLowerCase().startsWith("quest/")) return "";
      return m.name;
    }
  }
  return "";
}

// Optional thinking level for the delegation request. Absent means inherit —
// the extension never fabricates a level the registry may not carry.
export function resolveReviewThinking(): string | undefined {
  const raw = readEnv("PI_REVIEW_THINKING") ?? readEnv("PI_CRITICAL_REVIEW_THINKING");
  if (raw === undefined) return undefined;
  const level = raw.toLowerCase().trim();
  return THINKING_LEVELS.has(level) ? level : undefined;
}


export type ReviewTimeoutLayer =
  | "subagent_bridge_deadline"
  | "child_process_deadline"
  | "provider_model_timeout"
  | "quest_journal_deadline";

export function classifyTimeoutLayer(errMessage: string): ReviewTimeoutLayer {
  const msg = (errMessage || "").toLowerCase();
  if (/\bevent bridge\b|\bbridge\b/.test(msg)) return "subagent_bridge_deadline";
  if (/\b(?:killed|sigterm|sigkill|spawn)\b|child process/.test(msg)) return "child_process_deadline";
  if (isProviderSideFailure(msg)) return "provider_model_timeout";
  return "quest_journal_deadline";
}

export function isModelResolutionOrProviderError(errMessage: string): boolean {
  return isRetryableProviderError(errMessage || "");
}

export interface ReviewModelCandidate {
  model?: string;
  label: string;
}

export interface ReviewModelCandidateOptions {
  routerDefault?: string | string[];
  sessionModel?: string;
  appendInherit?: boolean;
}

export function extractProvider(model?: string): string {
  if (!model) return "";
  const trimmed = model.trim();
  const slashIdx = trimmed.indexOf("/");
  if (slashIdx > 0) return trimmed.substring(0, slashIdx).toLowerCase();
  return "";
}

// Ordered launch candidates: the resolved target first (it may carry a
// thinking suffix the child registry never registered), then the
// suffix-stripped variant, then the operator fallback. An empty target yields
// a single inherit attempt (no `model` field is sent), plus the fallback when
// one is configured.
// When options (routerDefault, sessionModel, appendInherit) are provided,
// robust fallbacks are appended to ensure rate-limited models never halt the review.
export function reviewModelCandidates(
  targetModel: string,
  fallbackModels: readonly string[] = [],
  options?: ReviewModelCandidateOptions,
): ReviewModelCandidate[] {
  let target = targetModel.trim();
  if (target.toLowerCase().startsWith("quest/")) target = "";
  const candidates: ReviewModelCandidate[] = target === ""
    ? [{ label: "inherit" }]
    : [{ model: target, label: target }];
  if (target !== "") {
    const stripped = stripThinkingSuffix(target);
    if (stripped !== "" && stripped !== target) {
      candidates.push({ model: stripped, label: stripped });
    }
  }
  // Configured fallbacks (roles.*Fallback) come before the env operator
  // fallback; each is tried verbatim, then its suffix-stripped variant.
  for (const raw of fallbackModels) {
    const fb = raw.trim();
    if (fb === "") continue;
    if (!candidates.some((c) => c.model === fb)) candidates.push({ model: fb, label: fb });
    const fbStripped = stripThinkingSuffix(fb);
    if (fbStripped !== "" && fbStripped !== fb && !candidates.some((c) => c.model === fbStripped)) {
      candidates.push({ model: fbStripped, label: fbStripped });
    }
  }
  const envFallback = readEnv("PI_CRITICAL_REVIEW_MODEL_FALLBACK");
  if (envFallback !== undefined) {
    const fallback = envFallback.trim();
    if (fallback !== "" && !candidates.some((c) => c.model === fallback)) {
      candidates.push({ model: fallback, label: fallback });
    }
  }

  // Auto-append router default model(s) if provided
  if (options?.routerDefault) {
    const defaults = Array.isArray(options.routerDefault) ? options.routerDefault : [options.routerDefault];
    for (const rd of defaults) {
      if (typeof rd !== "string") continue;
      const trimmed = rd.trim();
      if (trimmed === "") continue;
      if (!candidates.some((c) => c.model === trimmed)) candidates.push({ model: trimmed, label: trimmed });
      const rdStripped = stripThinkingSuffix(trimmed);
      if (rdStripped !== "" && rdStripped !== trimmed && !candidates.some((c) => c.model === rdStripped)) {
        candidates.push({ model: rdStripped, label: rdStripped });
      }
    }
  }

  // Auto-append active session model if provided and different
  if (options?.sessionModel) {
    const sm = options.sessionModel.trim();
    if (sm !== "" && !sm.toLowerCase().startsWith("quest/")) {
      if (!candidates.some((c) => c.model === sm)) candidates.push({ model: sm, label: sm });
      const smStripped = stripThinkingSuffix(sm);
      if (smStripped !== "" && smStripped !== sm && !candidates.some((c) => c.model === smStripped)) {
        candidates.push({ model: smStripped, label: smStripped });
      }
    }
  }

  // Auto-append inherit fallback as safety floor when requested
  if (options?.appendInherit && !candidates.some((c) => c.label === "inherit")) {
    candidates.push({ label: "inherit" });
  }

  return candidates;
}
