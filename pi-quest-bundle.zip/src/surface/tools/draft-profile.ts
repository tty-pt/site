// HIGH_LEVEL: #tools (main agent) — checkPlan/checkAnalysis report the
// deterministic draft profile without writing or booting a review, so the
// agent builds up to the maturity bar before paying for a reviewer run.
import { readFile } from "node:fs/promises";
import { join } from "node:path";
import type { PiCtx } from "../../hooks/events";
import type { QuestKind, QuestState } from "../../domain/quest";
import { draftPath } from "../../domain/paths";
import { draftFilePath } from "../../files";
import { getState } from "../../app/store";
import { readQuestConfig, getThresholdsForDifficulty, type QuestConfig } from "../../config";
import { draftProfileText, parseDraftSections, spliceAnalysisSection, splicePlanSection } from "../../drafting/plan-text";
import { checkPlanCitations } from "./claims";
import { assessDraftQuality } from "../../drafting/quality";
import { withEffectivePolicy } from "../../policy/effective";

// Which review policy is in force for the active model, so the agent sees why.
function policyLine(config: QuestConfig, ctx: PiCtx): string {
  const eff = withEffectivePolicy(config, ctx);
  return eff.policyNote === undefined ? "" : `review policy: ${eff.reviewPolicy} (${eff.policyNote})`;
}

async function deliverableProfile(
  ctx: PiCtx,
  state: QuestState,
  splice: (text: string, body: string) => string,
  body: string,
  kind: QuestKind,
  param: string,
): Promise<{ text?: string; error?: string }> {
  if (state.phase !== "drafting" || state.draft === null || state.qid === null) {
    return { error: `${param} needs a draft in drafting (phase ${state.phase}); author one via draftName first` };
  }
  const path = draftFilePath(ctx.cwd, state.qid);
  let current: string;
  try {
    current = await readFile(path, "utf8");
  } catch {
    return { error: `draft file missing at ${draftPath(state.qid)}` };
  }
  // Splice the would-be body onto the current draft so the profile reflects
  // exactly what a save would review.
  const updated = splice(current, body);
  const sections = parseDraftSections(updated);
  const config = await readQuestConfig(ctx.cwd);
  const thresholds = getThresholdsForDifficulty(config, state.difficulty);
  const claims = await checkPlanCitations(ctx, body);
  const quality = await assessDraftQuality(ctx, config, sections, kind, state.difficulty);
  const policy = policyLine(config, ctx);
  const extra = [claims, quality.summary, policy].filter((l) => l !== "").join("\n");
  return { text: draftProfileText(sections, thresholds, extra, kind, state.difficulty) };
}

export async function applyPlanCheck(
  ctx: PiCtx,
  state: QuestState,
  planBody: string,
): Promise<{ text?: string; error?: string }> {
  return deliverableProfile(ctx, state, splicePlanSection, planBody, "standard", "checkPlan");
}

export async function applyAnalysisCheck(
  ctx: PiCtx,
  state: QuestState,
  analysisBody: string,
): Promise<{ text?: string; error?: string }> {
  return deliverableProfile(ctx, state, spliceAnalysisSection, analysisBody, "analysis", "checkAnalysis");
}

export async function profileForSavedDoc(ctx: PiCtx, docText: string, kind: QuestKind = "standard"): Promise<string> {
  const config = await readQuestConfig(ctx.cwd);
  const state = getState();
  const thresholds = getThresholdsForDifficulty(config, state.difficulty);
  const sections = parseDraftSections(docText);
  const quality = await assessDraftQuality(ctx, config, sections, kind, state.difficulty);
  const extra = [quality.summary, policyLine(config, ctx)].filter((l) => l !== "").join("\n");
  return draftProfileText(sections, thresholds, extra, kind, state.difficulty);
}

// The quest_update_state { checkPlan } parameter: a pure read-only probe that
// never writes or boots a review and never creates a quest.
export async function checkPlanParam(
  ctx: PiCtx,
  params: Record<string, unknown>,
): Promise<{ applied: string[]; error?: string }> {
  const body = params["checkPlan"];
  if (typeof body !== "string" || body.trim() === "") return { applied: [] };
  const check = await applyPlanCheck(ctx, getState(), body.trim());
  if (check.error !== undefined) return { applied: [], error: check.error };
  return { applied: [check.text ?? ""] };
}

export async function checkAnalysisParam(
  ctx: PiCtx,
  params: Record<string, unknown>,
): Promise<{ applied: string[]; error?: string }> {
  const body = params["checkAnalysis"];
  if (typeof body !== "string" || body.trim() === "") return { applied: [] };
  const check = await applyAnalysisCheck(ctx, getState(), body.trim());
  if (check.error !== undefined) return { applied: [], error: check.error };
  return { applied: [check.text ?? ""] };
}