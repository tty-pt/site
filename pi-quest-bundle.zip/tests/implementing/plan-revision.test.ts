import { check } from "../check.ts";
import { mkdtempSync } from "node:fs";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { getState, replaceState, updateState } from "../../src/app/store.ts";
import {
  createQuest,
  IDLE_STATE,
} from "../../src/domain/quest.ts";
import {
  createDraft,
  promote,
} from "../../src/domain/transitions.ts";
import {
  approvePlanRevision,
  recordPlanRevision,
  revertPlanRevision,
} from "../../src/domain/plan-revision.ts";
import { draftPath } from "../../src/domain/paths.ts";
import type { QuestState } from "../../src/domain/quest.ts";
import type { Qid } from "../../src/domain/qid.ts";
import { implementationFingerprint } from "../../src/review/flow.ts";
import { formatRevisionHistory } from "../../src/validation/flow.ts";
import { buildReviewPrompt } from "../../src/review/prompts.ts";
import { installDraftGate } from "../../src/drafting/gate.ts";
import { cancelReview, hasInFlight, trackReview } from "../../src/review/tracker.ts";
import { hashContent } from "../../src/drafting/plan-text.ts";
import { applyUpdate } from "../../src/surface/tools/update-state.ts";
import { DEFAULT_CONFIG } from "../../src/config.ts";
import { stopBlink } from "../../src/durability/index.ts";
import type { Pi, ToolCallEvent } from "../../src/hooks/events.ts";
import { fakeCtx, fakePi } from "../fake-pi.ts";
import type { FakePi, SentMessage } from "../fake-pi.ts";
import {
  MAX_REVISION_RETRIES,
  REVISION_RETRY_BASE_MS,
  bootPlanRevisionReview,
  clearPlanRevisionRetries,
  handleApproveInput,
  planRevisionRetryCount,
  setRevisionRetryDispatcher,
} from "../../src/implementing/plan-revision.ts";

const QID = "abc123" as Qid;

function authored() {
  const s = createDraft(createQuest("req", QID), "thing");
  return { ...s, draft: { ...s.draft!, planAuthored: true, contentHash: "hash-v1" } };
}

function implementing(): QuestState {
  return promote(authored(), "review");
}

function tmp(): string {
  return mkdtempSync(join(tmpdir(), "pi-quest-revision-"));
}

Deno.test("promotion binds the approved plan hash", () => {
  const s = implementing();
  check(s.draft?.approvedPlanHash === "hash-v1", "approved hash bound at promote");
  check((s.draft?.planRevisions ?? []).length === 0, "no revisions yet");
});

Deno.test("recordPlanRevision appends history and keeps the old binding", () => {
  const s = recordPlanRevision(implementing(), "hash-v1", "hash-v2", "step 3 was wrong", "old plan", 7);
  check(s.draft?.contentHash === "hash-v2", "content moves to the revision");
  check(s.draft?.approvedPlanHash === "hash-v1", "binding stays on the approved plan");
  check(s.draft?.planRevisions.length === 1, "history appended");
  check(s.draft?.planRevisions[0].plan === "old plan", "prior text kept");
  check(s.draft?.planRevisions[0].note === "step 3 was wrong", "note kept");
  check(s.snapshotPending, "marks pending");
  for (const fn of [
    () => recordPlanRevision(authored(), "h1", "h2", "n", "p"),
    () => recordPlanRevision(implementing(), "", "h2", "n", "p"),
    () => recordPlanRevision(implementing(), "h1", "", "n", "p"),
  ]) {
    let threw = false;
    try {
      fn();
    } catch {
      threw = true;
    }
    check(threw, "bad revision rejected");
  }
});

Deno.test("approvePlanRevision adopts the revision", () => {
  const staged = recordPlanRevision(implementing(), "hash-v1", "hash-v2", "fix", "old plan");
  const s = approvePlanRevision(staged, "hash-v2", "new plan");
  check(s.draft?.approvedPlanHash === "hash-v2", "binding moves on approval");
  check(s.draft?.lastReviewedPlan === "new plan", "review baseline follows");
  check(s.phase === "implementing", "stays implementing");
  let threw = false;
  try {
    approvePlanRevision(authored(), "h", "p");
  } catch {
    threw = true;
  }
  check(threw, "approval outside implementing rejected");
});

Deno.test("revertPlanRevision restores the approved binding and keeps history", () => {
  const staged = recordPlanRevision(implementing(), "hash-v1", "hash-v2", "fix", "old plan");
  const s = revertPlanRevision(staged);
  check(s.draft?.contentHash === "hash-v1", "content restored to approved");
  check(s.draft?.planRevisions.length === 1, "history stays append-only");
});

Deno.test("implementation fingerprint binds the plan hashes", () => {
  const base = implementationFingerprint(implementing());
  const revised = recordPlanRevision(implementing(), "hash-v1", "hash-v2", "fix", "old");
  check(implementationFingerprint(revised) !== base, "staged revision changes the fingerprint");
  const approved = approvePlanRevision(revised, "hash-v2", "new");
  check(implementationFingerprint(approved) !== base, "adopted revision changes the fingerprint");
  check(implementationFingerprint(approved) !== implementationFingerprint(revised), "adopt differs from staged");
  check(implementationFingerprint(implementing()) === base, "same plan, same fingerprint");
});

Deno.test("legacy snapshots without revision fields still work", () => {
  const legacy = {
    ...implementing(),
    draft: { name: "thing", planAuthored: true, approvedBy: "review", outstandingFindings: false, contentHash: "hash-v1" },
  } as unknown as QuestState;
  const fp = implementationFingerprint(legacy);
  check(typeof fp === "string" && fp.length === 64, "fingerprint tolerates missing fields");
  const staged = recordPlanRevision(legacy, "hash-v1", "hash-v2", "fix", "old plan");
  check(staged.draft?.planRevisions.length === 1, "history starts from empty");
  check((staged.draft?.approvedPlanHash ?? null) === null, "missing binding reads as null");
});

Deno.test("revision history formats notes with truncated prior text", () => {
  check(formatRevisionHistory(implementing()).length === 0, "unrevised quest has no history");
  const staged = recordPlanRevision(implementing(), "hash-v1", "hash-v2", "step 3 was wrong", "old plan", 1720000000000);
  const lines = formatRevisionHistory(staged);
  check(lines.length === 1, "one line per revision");
  check(lines[0].includes("step 3 was wrong"), "note kept");
  check(lines[0].includes("hash-v1"), "superseded hash kept");
  check(lines[0].includes("old plan"), "prior text kept");
  const long = recordPlanRevision(implementing(), "h1", "h2", "fix", "x".repeat(2000));
  const capped = formatRevisionHistory(long);
  check(capped[0].length < 900, "prior text truncated");
  check(capped[0].includes("(truncated)"), "truncation marked");
  const legacy = { ...implementing(), draft: { ...implementing().draft!, planRevisions: undefined } } as unknown as QuestState;
  check(formatRevisionHistory(legacy).length === 0, "legacy drafts format as empty");
});

Deno.test("revision note renders in the re-review brief", () => {
  const prompt = buildReviewPrompt("draft", QID, "hash-v2", {
    objective: "ship it",
    plan: "new plan",
    evidence: [],
    amendments: [],
    planDiff: "- old\n+ new",
    revisionNote: "mid-implementation revision: objective unchanged",
  });
  check(prompt.includes("mid-implementation revision"), "revision context present");
  check(prompt.includes("- old"), "diff present");
});

type Handler = (event: ToolCallEvent, ctx: unknown) => { block?: boolean; reason?: string; terminate?: boolean } | undefined;

function captureGate(): Handler {
  const pi = fakePi();
  let captured: Handler | undefined;
  (pi as { on: unknown }).on = (_event: string, handler: unknown) => {
    captured = handler as Handler;
  };
  installDraftGate(pi as unknown as Pi);
  if (!captured) throw new Error("gate never subscribed");
  return captured;
}

Deno.test("gate tightens while a plan-revision review runs", () => {
  const handler = captureGate();
  replaceState(implementing());
  try {
    trackReview(QID, "hash-v2", () => {});
    const ctx = fakeCtx("/tmp");
    const write = { type: "tool_call", toolCallId: "1", toolName: "edit", input: { path: "src/impl.ts" } } as ToolCallEvent;
    const blocked = handler(write, ctx);
    check(blocked?.block === true, "writes blocked mid-revision-review");
    check(blocked?.terminate === true, "turn ends mid-revision-review");
    check(String(blocked?.reason).includes("PLAN_REVISION_REVIEW"), "reason names the revision review");
    const read = { type: "tool_call", toolCallId: "2", toolName: "read", input: { path: "src/impl.ts" } } as ToolCallEvent;
    check(handler(read, ctx)?.block === true, "reads blocked too, like drafting");
    const journal = { type: "tool_call", toolCallId: "3", toolName: "quest_update_state", input: {} } as ToolCallEvent;
    check(handler(journal, ctx) === undefined, "journal ops stay usable");
    const draftWrite = { type: "tool_call", toolCallId: "4", toolName: "edit", input: { path: draftPath(QID) } } as ToolCallEvent;
    const held = handler(draftWrite, ctx);
    check(held?.block === true, "quest-doc edits blocked mid-revision-review — revisions go through quest_update_state");
    check(String(held?.reason).includes("PLAN_REVISION_REVIEW"), "hold names the revision review");
  } finally {
    cancelReview(QID);
    replaceState(IDLE_STATE);
  }
});

Deno.test("gate stays open in implementing with no revision review", () => {
  const handler = captureGate();
  replaceState(implementing());
  try {
    const write = { type: "tool_call", toolCallId: "1", toolName: "edit", input: { path: "src/impl.ts" } } as ToolCallEvent;
    check(handler(write, fakeCtx("/tmp")) === undefined, "implementing stays unrestricted");
  } finally {
    replaceState(IDLE_STATE);
  }
});

Deno.test("planRevision writes the draft file from implementing", async () => {
  const cwd = tmp();
  const pi = fakePi();
  const ctx = fakeCtx(cwd);
  replaceState(implementing());
  try {
    const { writeFile, mkdir } = await import("node:fs/promises");
    await mkdir(join(cwd, ".pi/quest/future"), { recursive: true });
    await writeFile(join(cwd, draftPath(QID)), "# t\n\n## Implementation Plan\n\nold plan\n", "utf8");
    const done = await applyUpdate(pi, ctx, { planRevision: "new plan", note: "step 3 was wrong" });
    check(done.applied.some((a) => a.includes("plan revision")), "revision applied");
    const onDisk = await readFile(join(cwd, draftPath(QID)), "utf8");
    check(onDisk.includes("new plan"), "revision spliced into the draft file");
    check(getState().draft?.planRevisions.length === 1, "history recorded");
    check(getState().draft?.approvedPlanHash === "hash-v1", "binding unchanged until review PASS");
  } finally {
    stopBlink();
    replaceState(IDLE_STATE);
  }
});

Deno.test("planRevision refuses outside implementing and guards scope", async () => {
  const pi = fakePi();
  const ctx = fakeCtx(tmp());
  replaceState(authored());
  try {
    const refused = await applyUpdate(pi, ctx, { planRevision: "new plan" });
    check(refused.error !== undefined, "revision refused outside implementing");
  } finally {
    stopBlink();
    replaceState(IDLE_STATE);
  }
  replaceState(implementing());
  try {
    const scoped = await applyUpdate(pi, ctx, { planRevision: "new plan", objective: "different goal" });
    check(scoped.error !== undefined && scoped.error.includes("scope"), "objective change refused as scope change");
    const plan = await applyUpdate(pi, ctx, { plan: "other plan" });
    check(plan.error !== undefined && plan.error.includes("amendment"), "plain plan still drafting-only");
  } finally {
    stopBlink();
    replaceState(IDLE_STATE);
  }
});

interface RevisionRetryRecord {
  delay: number;
  fire: () => void;
}

interface RevisionBus {
  pi: FakePi;
  emitted: Array<{ event: string; data: unknown }>;
  feed: (data: unknown) => void;
  schedules: RevisionRetryRecord[];
}

function revisionBus(): RevisionBus {
  const pi = fakePi();
  pi.toolNames = ["subagent"];
  const emitted: Array<{ event: string; data: unknown }> = [];
  const handlers = new Map<string, Array<(data: unknown) => void>>();
  (pi as { events: unknown }).events = {
    on: (event: string, handler: (data: unknown) => void) => {
      const list = handlers.get(event) ?? [];
      list.push(handler);
      handlers.set(event, list);
      return () => {};
    },
    emit: (event: string, data: unknown) => {
      emitted.push({ event, data });
    },
  };
  const feed = (data: unknown) => {
    for (const handler of handlers.get("prompt-template:subagent:response") ?? []) handler(data);
  };
  return { pi, emitted, feed, schedules: [] };
}

function revisionRequests(emitted: Array<{ event: string; data: unknown }>): Array<Record<string, unknown>> {
  return emitted
    .filter((e) => e.event === "prompt-template:subagent:request")
    .map((e) => e.data as Record<string, unknown>);
}

async function waitForRevisionRequests(
  emitted: Array<{ event: string; data: unknown }>,
  count: number,
): Promise<void> {
  for (let i = 0; i < 200 && revisionRequests(emitted).length < count; i += 1) {
    await new Promise((r) => setTimeout(r, 5));
  }
  check(revisionRequests(emitted).length >= count, `expected ${count} review attempts`);
}

function revisionWakes(pi: FakePi): Array<SentMessage["message"]> {
  return pi.sent.filter((m) => m.options?.triggerTurn === true).map((m) => m.message);
}

async function revisionFailureSetup(): Promise<{ cwd: string; target: string; content: string; qid: Qid }> {
  const cwd = tmp();
  const qid = QID;
  replaceState(implementing());
  const content = "# t\n\n## Implementation Plan\n\nnew plan\n";
  await mkdir(join(cwd, ".pi/quest/future"), { recursive: true });
  await writeFile(join(cwd, draftPath(qid)), content, "utf8");
  const target = hashContent(content);
  return { cwd, target, content, qid };
}

Deno.test("a failed plan-revision review retries the same target and adopts on PASS", async () => {
  const d = await revisionFailureSetup();
  const bus = revisionBus();
  const prior = setRevisionRetryDispatcher((delay, fire) => {
    bus.schedules.push({ delay, fire });
  });
  try {
    const booted = bootPlanRevisionReview(bus.pi, fakeCtx(d.cwd), d.target, DEFAULT_CONFIG);
    await waitForRevisionRequests(bus.emitted, 1);
    bus.feed({ requestId: revisionRequests(bus.emitted)[0]["requestId"], status: "error", error: "boom" });
    await booted;
    check(bus.schedules.length === 1, "first retry scheduled");
    check(bus.schedules[0].delay === REVISION_RETRY_BASE_MS, "base backoff");
    check(planRevisionRetryCount(d.qid) === 1, "revision retry count recorded");
    check(revisionWakes(bus.pi).length === 0, "no wake while retrying");
    const onDisk = await readFile(join(d.cwd, draftPath(d.qid)), "utf8");
    check(onDisk === d.content, "staged plan untouched at scheduling time");
    await bus.schedules[0].fire();
    await waitForRevisionRequests(bus.emitted, 2);
    bus.feed({
      requestId: revisionRequests(bus.emitted)[1]["requestId"],
      status: "completed",
      result: { kind: "text", text: "VERDICT: PASS\nSEVERITY: NONE" },
    });
    await new Promise((r) => setTimeout(r, 10));
    check(getState().draft?.approvedPlanHash === d.target, "revision adopted on retried PASS");
    check(getState().phase === "implementing", "stays implementing");
    check(planRevisionRetryCount(d.qid) === 0, "counter cleared on verdict");
  } finally {
    setRevisionRetryDispatcher(prior);
    cancelReview(d.qid);
    clearPlanRevisionRetries(d.qid);
    replaceState(IDLE_STATE);
  }
});

Deno.test("plan-revision retries cap out and wake without self-approval", async () => {
  const d = await revisionFailureSetup();
  const bus = revisionBus();
  const prior = setRevisionRetryDispatcher((delay, fire) => {
    bus.schedules.push({ delay, fire });
  });
  try {
    const booted = bootPlanRevisionReview(bus.pi, fakeCtx(d.cwd), d.target, DEFAULT_CONFIG);
    await waitForRevisionRequests(bus.emitted, 1);
    bus.feed({ requestId: revisionRequests(bus.emitted)[0]["requestId"], status: "error", error: "boom" });
    await booted;
    for (let step = 1; step <= MAX_REVISION_RETRIES; step += 1) {
      check(bus.schedules.length === step, `retry ${step} scheduled`);
      await bus.schedules[step - 1].fire();
      await waitForRevisionRequests(bus.emitted, step + 1);
      bus.feed({ requestId: revisionRequests(bus.emitted)[step]["requestId"], status: "error", error: "boom" });
      await new Promise((r) => setTimeout(r, 10));
    }
    check(bus.schedules.length === MAX_REVISION_RETRIES, "no retry past the cap");
    const sentWakes = revisionWakes(bus.pi);
    check(sentWakes.length === 1, "woken exactly once, at the cap");
    const text = String(sentWakes[0].content);
    check(text.includes(`failed ${MAX_REVISION_RETRIES} times`), "cap named");
    check(!text.includes("proceed on your judgment"), "no self-judgment escape");
    check(planRevisionRetryCount(d.qid) === 0, "counter reset at cap");
    const onDisk = await readFile(join(d.cwd, draftPath(d.qid)), "utf8");
    check(onDisk === d.content, "previous plan still stands after the cap");
  } finally {
    setRevisionRetryDispatcher(prior);
    cancelReview(d.qid);
    clearPlanRevisionRetries(d.qid);
    replaceState(IDLE_STATE);
  }
});

Deno.test("plan revision under reviewPolicy off auto-adopts without subagent", async () => {
  const d = await revisionFailureSetup();
  const bus = revisionBus();
  try {
    const offConfig = { ...DEFAULT_CONFIG, reviewPolicy: "off" as const };
    await bootPlanRevisionReview(bus.pi, fakeCtx(d.cwd), d.target, offConfig);
    check(revisionRequests(bus.emitted).length === 0, "zero subagents under policy off");
    check(getState().draft?.approvedPlanHash === d.target, "plan revision adopted");
    const sentWakes = revisionWakes(bus.pi);
    check(sentWakes.length === 1, "wake announced adoption");
    check(String(sentWakes[0].content).includes("auto-approved under policy 'off'"), "announcement includes policy");
  } finally {
    cancelReview(d.qid);
    clearPlanRevisionRetries(d.qid);
    replaceState(IDLE_STATE);
  }
});

Deno.test("handleApproveInput adopts staged plan revision and cancels in-flight review", async () => {
  const d = await revisionFailureSetup();
  const bus = revisionBus();
  // Stage the revision in state
  updateState((s) => s.draft === null ? s : { ...s, draft: { ...s.draft, contentHash: d.target } });
  // Simulate an in-flight review
  trackReview(d.qid, d.target, () => {});
  check(hasInFlight(d.qid) === true, "review is in-flight");

  const adopted = await handleApproveInput(bus.pi, fakeCtx(d.cwd), "go");
  check(adopted === true, "handleApproveInput adopted staged revision");
  check(hasInFlight(d.qid) === false, "in-flight review was cancelled");
  check(getState().draft?.approvedPlanHash === d.target, "approved plan hash updated");

  cancelReview(d.qid);
  clearPlanRevisionRetries(d.qid);
  replaceState(IDLE_STATE);
});

Deno.test("handleApproveInput cancels in-flight review even when contentHash equals approvedPlanHash", async () => {
  const d = await revisionFailureSetup();
  const bus = revisionBus();
  // Plan hash equals approved hash (no staged revision)
  updateState((s) => s.draft === null ? s : { ...s, draft: { ...s.draft, contentHash: d.target, approvedPlanHash: d.target } });
  trackReview(d.qid, d.target, () => {});
  check(hasInFlight(d.qid) === true, "review is in-flight");

  const unblocked = await handleApproveInput(bus.pi, fakeCtx(d.cwd), "go");
  check(unblocked === true, "handleApproveInput handled approval to unblock stuck in-flight");
  check(hasInFlight(d.qid) === false, "in-flight review was cancelled");

  cancelReview(d.qid);
  clearPlanRevisionRetries(d.qid);
  replaceState(IDLE_STATE);
});


