import { check } from "../check.ts";
import { mkdirSync, mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { getState, replaceState } from "../../src/app/store.ts";
import { createQuest, IDLE_STATE } from "../../src/domain/quest.ts";
import { createDraft } from "../../src/domain/transitions.ts";
import type { Qid } from "../../src/domain/qid.ts";
import { draftPath } from "../../src/domain/paths.ts";
import type { OverlayFactory, OverlayShowOptions, PiCtx, PiOverlayComponent, PiTheme } from "../../src/hooks/events.ts";
import { installCommands } from "../../src/surface/commands/index.ts";
import { viewActivePlan } from "../../src/surface/commands/plan.ts";
import { fakeCtx, fakePi } from "../fake-pi.ts";

const QID = "abc123" as Qid;
const DRAFT = "## Requirements\n- first\n\n## Evidence\n- found it\n\n## Implementation Plan\nDo step one.\nThen step two.\n";

function draftingCwd(): string {
  const cwd = mkdtempSync(join(tmpdir(), "pi-quest-plan-"));
  mkdirSync(join(cwd, ".pi", "quest", "future"), { recursive: true });
  writeFileSync(join(cwd, draftPath(QID)), DRAFT);
  replaceState(createDraft(createQuest("work", QID), "work"));
  return cwd;
}

function withTerminalSize(rows: number, cols: number, run: () => Promise<void>): Promise<void> {
  const stdout = process.stdout as unknown as { rows?: number; columns?: number };
  const prevRows = Object.getOwnPropertyDescriptor(process.stdout, "rows");
  const prevCols = Object.getOwnPropertyDescriptor(process.stdout, "columns");
  Object.defineProperties(process.stdout, {
    rows: { value: rows, configurable: true },
    columns: { value: cols, configurable: true },
  });
  return (async () => {
    try {
      await run();
    } finally {
      if (prevRows) Object.defineProperty(process.stdout, "rows", prevRows);
      else delete stdout.rows;
      if (prevCols) Object.defineProperty(process.stdout, "columns", prevCols);
      else delete stdout.columns;
    }
  })();
}

Deno.test("DEBUGCTRLQ ctrl+q via onTerminalInput opens the plan viewer", async () => {
  const cwd = draftingCwd();
  let opened = false;
  const ctx = fakeCtx(cwd, [], {
    notify: () => {},
    custom: <T>(): Promise<T> => {
      opened = true;
      return Promise.resolve(undefined as unknown as T);
    },
  });
  ctx.mode = "tui";
  const { default: install } = await import("../../src/index.ts");
  const pi = fakePi();
  install(pi);
  // Fire the session_start handler to register onTerminalInput.
  const handlers = pi.eventHandlers["session_start"] ?? [];
  check(handlers.length >= 1, "session_start handler registered");
  for (const h of handlers) h({ type: "session_start", reason: "test" }, ctx);
  // The onTerminalInput handler should now be registered.
  check(ctx.inputHandlers.length >= 1, "onTerminalInput registered");
  const handler = ctx.inputHandlers[ctx.inputHandlers.length - 1];
  const t0 = performance.now(); const qidAtPress = getState().qid; const result = handler("\x11"); // raw ctrl+Q
  check(result?.consume === true, "ctrl+Q consumed");
  await new Promise((r) => setTimeout(r, 50)); // let async viewActivePlan settle (file I/O)
  Deno.writeTextFileSync("/tmp/ctrlq-debug.log", JSON.stringify({ opened, qidAtPress, qidAfter: getState().qid, waitedMs: Math.round(performance.now() - t0), phase: getState().phase }) + "\n", { append: true });
  check(opened, "viewer opened on ctrl+Q");
  // Non-ctrl+Q passes through.
  opened = false;
  const pass = handler("j");
  check(pass === undefined, "other keys pass through");
  check(!opened, "viewer not opened for other keys");
  replaceState(IDLE_STATE);
});
