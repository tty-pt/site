import { check } from "../check.ts";
import type { Qid } from "../../src/domain/qid.ts";
import type { QuestState } from "../../src/domain/quest.ts";
import { createQuest, IDLE_STATE } from "../../src/domain/quest.ts";
import { createDraft } from "../../src/domain/transitions.ts";
import { draftPath } from "../../src/domain/paths.ts";
import type { ToolRef } from "../../src/domain/gates.ts";
import { decide, reasonText } from "../../src/domain/gates.ts";

const QID = "abc123" as Qid;

function ref(toolName: string, toolClass: ToolRef["toolClass"], path?: string): ToolRef {
  return path === undefined ? { toolName, toolClass } : { toolName, toolClass, path };
}

const EDIT_OTHER = ref("edit", "write", "src/impl.ts");
const READ = ref("read", "read", "src/impl.ts");
const JOURNAL = ref("quest_update_state", "journal");
const ASK = ref("ask_questions", "ask");
const OTHER = ref("mystery_tool", "other");
const LAUNCH = ref("subagent", "launch");

function drafting() {
  return createDraft(createQuest("req", QID), "thing");
}

function analyzing() {
  return createDraft(createQuest("req", QID), "thing", "analysis");
}

Deno.test("gate exempts the draft file only during drafting", () => {
  const draftWrite = ref("edit", "write", draftPath(QID));
  const revision = { ...drafting(), draft: { ...drafting().draft!, outstandingFindings: true } };
  check(decide(revision, draftWrite).allowed, "exempt under revision in drafting");
  const midReview = { ...drafting(), activeReview: { kind: "draft" as const, target: "h1" } };
  check(decide(midReview, draftWrite).allowed, "exempt mid-review in drafting");
  check(decide(midReview, draftWrite, { isReviewerSession: true }).allowed, "exemption beats reviewer row in drafting");
  const implementing = { ...drafting(), phase: "implementing" as const };
  const blockedImpl = decide(implementing, draftWrite);
  check(!blockedImpl.allowed && blockedImpl.code === "IMPLEMENTATION_BLOCKED", "quest doc locked during implementing");
  const validating = { ...drafting(), phase: "validating" as const };
  const blockedVal = decide(validating, draftWrite);
  check(!blockedVal.allowed && blockedVal.code === "IMPLEMENTATION_BLOCKED", "quest doc locked during validating");
});

Deno.test("QUEST_DOC_LOCKED names planRevision and claimComplete", () => {
  const implementing = { ...drafting(), phase: "implementing" as const };
  const d = decide(implementing, ref("edit", "write", draftPath(QID)));
  check(!d.allowed, "blocked");
  if (!d.allowed) {
    check(d.phaseName === "QUEST_DOC_LOCKED", "locked state name");
    check(d.action.includes("planRevision"), "action mentions planRevision");
    check(d.action.includes("claimComplete"), "action mentions claimComplete");
  }
});

Deno.test("gate keeps reviewers read-only", () => {
  const state = { ...drafting(), phase: "implementing" as const };
  check(decide(state, READ, { isReviewerSession: true }).allowed, "reviewer reads open");
  const write = decide(state, EDIT_OTHER, { isReviewerSession: true });
  check(!write.allowed && write.code === "IMPLEMENTATION_BLOCKED", "reviewer writes blocked");
  if (!write.allowed) {
    check(write.phaseName === "REVIEWER_READ_ONLY", "reviewer state name");
    check(reasonText(write).includes("REVIEWER_READ_ONLY"), "reason carries state");
  }
  check(!decide(state, JOURNAL, { isReviewerSession: true }).allowed, "reviewers never call quest tools");
});

Deno.test("gate always allows reads, journal ops, and questions", () => {
  for (const r of [READ, JOURNAL, ASK]) {
    check(decide(drafting(), r).allowed, `${r.toolName} allowed in drafting`);
  }
  check(decide(createQuest("req", QID), READ).allowed, "read allowed in provisional");
});

Deno.test("gate blocks implementation in provisional", () => {
  const d = decide(createQuest("req", QID), EDIT_OTHER);
  check(!d.allowed && d.code === "RESEARCH_REQUIRED", "provisional blocked");
  if (!d.allowed) check(d.phaseName === "PROVISIONAL_RESEARCH_PENDING", "provisional name");
});

Deno.test("gate blocks unauthored and revision drafts", () => {
  const pending = decide(drafting(), EDIT_OTHER);
  check(!pending.allowed && pending.code === "DRAFT_REVIEW_REQUIRED", "unauthored blocked");
  if (!pending.allowed) {
    check(pending.phaseName === "DRAFT_PENDING", "pending name");
    check(reasonText(pending).includes("future/abc123.md"), "reason names the draft file");
  }
  const s = drafting();
  const revision = { ...s, draft: { ...s.draft!, outstandingFindings: true } };
  const d = decide(revision, EDIT_OTHER);
  check(!d.allowed, "revision blocked");
  if (!d.allowed) check(d.phaseName === "DRAFT_REVISION_PENDING", "revision name");
});

Deno.test("revision gate echoes the last review findings instead of a bare pointer", () => {
  const s = drafting();
  const revision = {
    ...s,
    draft: { ...s.draft!, outstandingFindings: true },
    lastReview: { verdict: "FAIL" as const, target: "h1", findings: "double-free in the responder; line cites off at gig.c:751" },
  };
  const d = decide(revision, EDIT_OTHER);
  check(!d.allowed, "revision blocked");
  if (!d.allowed) {
    check(reasonText(d).includes("double-free"), "findings reach the blocked write");
    check(reasonText(d).includes("gig.c:751"), "detail reaches the blocked write");
  }
});

Deno.test("gate leaves idle and archived open", () => {
  check(decide(IDLE_STATE, EDIT_OTHER).allowed, "idle open");
  check(decide(IDLE_STATE, LAUNCH).allowed, "idle launch open");
  check(decide({ ...IDLE_STATE, phase: "archived" }, EDIT_OTHER).allowed, "archived open");
});

Deno.test("gate blocks writes while a review runs", () => {
  const s = drafting();
  const authored = { ...s, draft: { ...s.draft!, planAuthored: true } };
  const midReview = { ...authored, activeReview: { kind: "draft" as const, target: "h1" } };
  const d = decide(midReview, EDIT_OTHER);
  check(!d.allowed && d.code === "PLAN_REVIEW_REQUIRED", "review blocks writes");
  if (!d.allowed) check(d.action.includes("end your turn"), "reason ends the turn");
  check(!decide(midReview, READ).allowed, "review blocks reads too — the turn ends");
  check(decide(midReview, JOURNAL).allowed, "journal ops stay usable mid-review");
});

Deno.test("gate never blocks the live asking tool, even mid-review", () => {
  const live = ref("ask_user_question", "ask");
  const s = drafting();
  const authored = { ...s, draft: { ...s.draft!, planAuthored: true } };
  const midReview = { ...authored, activeReview: { kind: "draft" as const, target: "h1" } };
  check(decide(midReview, live).allowed, "live ask allowed mid-review");
  check(decide(createQuest("req", QID), live).allowed, "live ask allowed in provisional");
  check(decide(drafting(), live).allowed, "live ask allowed in drafting");
  check(!decide(midReview, ref("ask_user_question", "other")).allowed, "misclassified ask still blocked");
});

Deno.test("gate opens implementation and allows unknown tools while drafting", () => {
  const open: QuestState = { ...drafting(), phase: "implementing" };
  check(decide(open, EDIT_OTHER).allowed, "implementing open");
  check(decide(open, LAUNCH).allowed, "implementing launch open");
  check(decide(drafting(), OTHER).allowed, "unknown non-mutating tool not blocked while drafting");
});

Deno.test("gate lets read-only runtime tools like vcc_recall through every phase", () => {
  const recall = ref("vcc_recall", "other");
  check(decide(createQuest("req", QID), recall).allowed, "vcc_recall allowed in provisional");
  check(decide(drafting(), recall).allowed, "vcc_recall allowed in drafting");
  const implementing = { ...drafting(), phase: "implementing" as const };
  check(decide(implementing, recall).allowed, "vcc_recall allowed in implementing");
  const validating = { ...drafting(), phase: "validating" as const };
  check(decide(validating, recall).allowed, "vcc_recall allowed in validating");
});

Deno.test("gate locks every non-draft write while drafting, authored plan or not", () => {
  const s = drafting();
  const authored = { ...s, draft: { ...s.draft!, planAuthored: true } };
  const d = decide(authored, EDIT_OTHER);
  check(!d.allowed && d.code === "DRAFT_REVIEW_REQUIRED", "authored plan still locks other files");
  if (!d.allowed) {
    check(d.phaseName === "DRAFT_LOCKED", "draft-locked state name");
    check(d.action.includes(draftPath(QID)), "reason names the quest doc as the only writable file");
  }
  check(!decide(authored, LAUNCH).allowed, "launch blocked while drafting");
  const midReview = { ...authored, activeReview: { kind: "draft" as const, target: "h1" } };
  const held = decide(midReview, EDIT_OTHER);
  check(!held.allowed && held.code === "PLAN_REVIEW_REQUIRED", "active-review row still outranks the phase lock");
  check(decide(authored, READ).allowed, "reads remain open");
  check(decide(authored, JOURNAL).allowed, "journal stays open");
  check(decide(authored, ASK).allowed, "questions stay open");
});

Deno.test("gate locks writes while validating", () => {
  const validating = { ...drafting(), phase: "validating" as const };
  const d = decide(validating, EDIT_OTHER);
  check(!d.allowed && d.code === "VALIDATION_REQUIRED", "validating write blocked");
  if (!d.allowed) {
    check(d.phaseName === "VALIDATION_LOCKED", "validation-locked state name");
    check(d.action.includes("continueWork"), "action points out the exit");
  }
  check(decide(validating, READ).allowed, "validating reads open");
  check(decide(validating, JOURNAL).allowed, "journal stays open");
});

Deno.test("gate wording names the Analysis deliverable for analysis quests", () => {
  const pending = decide(analyzing(), EDIT_OTHER);
  check(!pending.allowed && pending.code === "DRAFT_REVIEW_REQUIRED", "analysis draft blocked");
  if (!pending.allowed) {
    check(pending.phaseName === "DRAFT_PENDING", "pending name");
    check(decide(analyzing(), EDIT_OTHER).allowed === false, "wording check keeps blocking");
    check(reasonText(pending).includes("## Analysis"), "names the analysis section");
    check(reasonText(pending).includes("{analysis: ...}"), "names the analysis param");
  }
  const authored = { ...analyzing(), draft: { ...analyzing().draft!, planAuthored: true } };
  const locked = decide(authored, EDIT_OTHER);
  if (!locked.allowed) {
    check(locked.phaseName === "DRAFT_LOCKED", "locked name");
    check(reasonText(locked).includes("promotion to validation"), "analysis promotion target");
  }
  const validating = { ...authored, phase: "validating" as const };
  const val = decide(validating, EDIT_OTHER);
  if (!val.allowed) {
    check(reasonText(val).includes("resume drafting"), "analysis validation exit wording");
  }
});
