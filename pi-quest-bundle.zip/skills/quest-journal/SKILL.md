---
name: quest-journal
description: "Quest Journal v2: drafting / implementing / validating modes per quest. Main agent only — reviewers receive the review brief, never this skill."
---

# Quest Journal v2 — main-agent workflow rules

You work inside quests. One quest is active at a time. Quest state lives in
the session transcript as `quest_journal` snapshots; `quest.md` files are
generated read-only views, never truth. Every quest has a short alphanumeric
quest id (`future/<qid>.md`); there are no slugs.

## Modes

- **Drafting.** The only write path, in order: (1) `quest_update_state`
  with findings to establish identity; (2) `quest_update_state` with
  `draftName` — the draft lives at `.pi/quest/future/<qid>.md` (its
  scaffold is pre-created when the quest starts, so never create
  directories yourself);
  (3) author the plan: EITHER call the `edit` tool with the draft file path
  (`{ "path": ".pi/quest/future/<qid>.md", "edits": [{ "oldText": "…",
  "newText": "…" }] }`) OR pass the whole plan body as
  `quest_update_state { "plan": "…" }` — the runtime splices it into the
  draft's `## Implementation Plan` for you. Every other write is
  blocked with the reason and the required next action. While a review runs,
  end your turn: the verdict arrives as a new turn. Research and read
  freely — searches, inspections, and test runs are never blocked. Structure
  the draft with `## Requirements`,
  `## Evidence`, and `## Implementation Plan` sections. Every
  content-changing save cancels the running review and boots a fresh
  adversarial reviewer. Reviewer verdicts are PASS or FAIL with findings.
  FAIL returns findings — revise the plan and save. PASS promotes you to
  implementing automatically (recorded research + actionable plan required).
  The user may reply `go` at any moment to promote immediately; approval is
  never required. Rebut a verdict with evidence via `quest_rebut`.
  `future/<qid>.md` stays the one quest document through implementing and
  validating; it is removed only when the quest archives.
- **Drafting to pass review in one pass.** Every save boots a fresh
  adversarial reviewer, so build up to the maturity bar before you save.
  The reviewer checks your *plan* against the recorded request along these
  dimensions: does it address the objective; are requirements omitted; did
  it substitute a different problem; is research sufficient; are assumptions
  verified; does the work sequence fit; is complexity unnecessary; was an
  alternative dismissed without evidence; does it commit prematurely; does it
  contradict itself; does it credibly satisfy the request. Draft so the
  answers are visibly yes:
  - Write requirements as numbered, objective-stated bullets. Thresholds scale
    dynamically with difficulty (`trivial`: 1 requirement + 2 evidence items;
    `standard`: 2 requirements, or 1 requirement + 7 evidence items;
    `complex`: 3 requirements + 10 evidence items) — below the bar, the reviewer
    fails fast.
  - **Review policies & autonomy:** under `reviewPolicy: "balanced"` (frontier mode),
    trivial and standard tasks auto-promote to coding immediately without subagent
    review delay; complex tasks undergo full review. Under `reviewPolicy: "off"`,
    all subagent reviews are bypassed while retaining full quest journal structure.
  - **Depth bar (`draftQuality`):** when review is bypassed (balanced/off) the plan is
    gated on more than counts. For `standard` quests: at least 2 `file:line` citations
    that really resolve in the repo (evidence or plan), at least 3 discrete plan steps
    written as a numbered/bulleted list (not prose), and an explicit verification step
    (a test or check). `complex` wants 4 citations / 5 steps; `trivial` almost nothing.
    The draft profile (`checkPlan`, every save) shows the quality line and what is
    missing — build up to it before saving. Cite only locations you actually read.
  - **Model-aware policy:** `policyByModel` may switch the review policy by the model in
    use, so the same repo can be balanced for a frontier model and strict for a weaker
    one. The draft profile names the rule when it applies.
  - **Two-strike safety pause:** if a review or validation is rejected 2 consecutive
    times, the automated review loop automatically pauses to prevent thrashing and
    prompts the human operator for guidance.
  - **Reviewer failover & cooldowns:** if the designated reviewer hits provider rate limits
    (429) or quota exhaustion, `pi-quest` cools down that provider for 15 minutes, skips
    sibling models under the same provider, and fails over across the fallback chain (to the
    router default, session model, or ambient inherit), preventing stalls.
  - **Human operator steering:** the operator is the supreme authority. Natural
    phrasing (`go`, `proceed`, `start coding` in drafting; `ship it`, `confirm`,
    `looks good` in validation) bypasses automated reviews and advances immediately.
  - **Sub-quest decomposition:** for complex tasks, define backlog items under
    `## Sub-Quests` using `- [ ] SQ1: Goal [paths: ...] [tests: ...] [req: ...]`.
    Upon plan approval, the Foreman automatically mounts `SQ1` into a bounded worker lane.
  - Distinguish a **user requirement** (blocks), a **technical constraint**
    (binds your approach), and a **reviewer preference** (never blocks).
    Each requirement needs evidence or a verification step; research you
    file via `refinement` lands as `## Findings (pre-draft investigation)`
    and counts as evidence.
  - Cite code-generation claims as `file:line` so the save-time claims check
    stays silent; the reviewer spot-checks named lines rather than
    re-auditing the tree.
  - **Preview before you pay:** call `quest_update_state` with
    `{ "checkPlan": "<plan body>" }` to read the deterministic draft profile
    (counts, maturity-bar verdict, citation resolution) without writing or
    booting a review. Iterate on the profile until it reads `maturity bar:
    met`, then save once.
  - Revise from the verbatim FAIL text the wake carries; a FAIL marks
    findings outstanding until your next save supersedes them.
- **Implementing.** Unrestricted. Record setbacks with evidence as they
  happen; nothing blocks. When reality contradicts the plan, record an
  amendment with reasons via `quest_update_state` — amendments adjust the
  plan, never the scope (scope change = new quest). Work from the quest's
  Exact Next Action. User remarks mid-quest are automatically captured as
  active directives and injected into your turn context; route separable work
  via `quest_subquest` and constraints via plan amendments.
  When done, claim completion via `quest_update_state` with `claimComplete`
  — an unverified claim that boots the validator immediately. The quest doc
  is locked to direct edits during implementing; all plan changes go through
  `planRevision` (peer-reviewed) and completion through `claimComplete`. The
  doc's `## Status` section tracks the phase but never marks completion as
  true on your say-so.
- **Validation.** A validator checks the implementation against the approved
  plan plus amendments. PASS: run `quest_archive` to finish (agent quest doc
  + rendered view + manifest). FAIL: findings return you to implementing and
  the doc's `## Status` is reset, so a fresh claim re-arms the trigger.
  Archived is final — follow-ups are new quests citing the old id.
- **Analysis quests.** Some requests ask for a verdict or decision rather
  than a change — `quest_update_state { "kind": "analysis" }` opens that
  mode at draft provisioning (explicit only; any other value errors, and
  `standard` is unchanged). The deliverable is the `## Analysis` section of
  the same `future/<qid>.md` document: author it via the `edit` tool or pass
  the whole body as `quest_update_state { "analysis": "…" }`; the runtime
  splices it in. Plan writes are refused on analysis quests and analysis
  writes on standard ones, each naming the correct section. Save-time
  review, thresholds, `checkAnalysis` probe, claim manifest, and the review
  counts all key off the analysis body.
  A review PASS auto-claims the quest straight to **validating** — there is
  no implementing phase — and boots the validator immediately (while
  sub-quests run, the analysis stays provisional and the quest stays in a
  work phase until children finish). The validator judges the analysis
  against the request plus a bounded transcript extract (~8k chars of the
  user/assistant thread, truncation-marked), never your full session.
  Validation PASS archives as usual; FAIL returns the quest to **drafting**
  (not implementing) with findings and resets the doc's `## Status`. The
  conclusion wake reproduces the delivered analysis when it matters most.

## Mid-Quest Operator Directives & Autonomous Triage

The operator may speak to you mid-quest without stopping or restarting the quest.
`pi-quest` captures these remarks into `state.refinements` and injects active directives
into your turn context on every turn under `[Active Mid-Quest Directives - Must be satisfied]:`.

When you receive a mid-quest directive, evaluate it using this decision protocol:
1. **Separable Task or New Feature** (e.g. *"Also build an export command"*, *"Handle the CSS in a subtask"*):
   - Do NOT try to cram unrelated work into your active single-lane plan.
   - Proactively spawn a sub-quest via `quest_subquest({ goal, brief, switchNow })`.
   - Set `switchNow: true` if the task is an immediate prerequisite/blocker, or `switchNow: false` if it can queue into the backlog for the autonomous Foreman.
2. **Constraint, Rule, or Course Correction** (e.g. *"Port must be 8080"*, *"Don't touch db.c"*, *"Ensure tests pass"*):
   - Incorporate the constraint into your implementation immediately.
   - Record an amendment via `quest_update_state { amendment: { change: "...", reasons: "Operator mid-quest directive" } }`.
3. **Conversational Question** (e.g. *"What does this function do?"*, *"Status?"*):
   - Answer the question directly in your conversational response. Do not modify the plan or open a sub-quest.

**Validation Invariant:** Every operator directive is part of the acceptance criteria verified
by the validator at completion. Claiming completion (`claimComplete: true`) while ignoring an
active user directive will cause validation to FAIL.

## Tools

- `quest_update_state` — your write path: findings, drafts, amendments,
  next action, completion claims. Emitting a snapshot IS persisting; there
  is no save step and no `quest_mark_saved`.
- `quest_subquest` — spawn a linked sub-quest for a complex sub-task. The
  parent waits; you resume on return with findings. Depth cap 3. A failed
  child never fails its parent — record, adjust, continue.
- `quest_archive` — finish as completed (needs a current validation PASS;
  claim via `quest_update_state` with `claimComplete` first), failed, or
  abandoned. Archiving unvalidated work as failed/abandoned requires
  `confirmDiscard:true` plus a summary of what was discarded and why.
  Archive zips the quest doc `future/<qid>.md` plus the rendered view and
  manifest into `archive/<qid>.zip` (sole artifact) and removes both sources.
- `quest_recover` — rebuild state from the transcript, including earlier
  sessions. Runs automatically when state is absent.
- `quest_rebut` — answer a review with evidence; a successful rebuttal
  reopens the question.
- `quest_ask_human` — ask with a recommended default and timeout (one
  minute default). It dispatches through question providers — tools with a
  working invocation protocol first, the built-in input prompt as the
  guaranteed fallback. Never blocks: absence, cancellation, or timeout
  proceeds with the default, and a late answer still applies when it
  arrives.

## Commands

`/quest` (resume by qid/name, show the active quest, or pick from current quests when idle — fresh sessions start with no active quest), `[^Q]` (floating plan viewer), `/quests` (list), `/quest-del` (archive/kill).
Everything else the system does by itself.

## Durability

State is stamped into the transcript on every change and re-read before
every reply: you survive compaction and restarts. If state is ever absent,
call `quest_recover`. Never hand-edit generated quest views.
